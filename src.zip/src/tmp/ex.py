def extend(name, ext):
    return name + '.' + ext
########## ########## ########## ########## ########## ########## ########## ##########

def parse(name):
    cmd = 'main ' + extend(name, 'l') + ' > ' + extend(name, 'p')
    print(cmd)

########## ########## ########## ########## ########## ########## ########## ##########

def solve(name):
    cmd =   'translator ' + extend(name, 'l') + \
            ' | java -jar sparc.jar -solver clingo -A -loutput'
    print(cmd)
        
########## ########## ########## ########## ########## ########## ########## ##########

def translate(name):
    cmd = 'translator ' + extend(name, 'l') + ' > ' + extend(name, 'sp')
    print(cmd)

def output(name):
    cmd =   'java -jar sparc.jar -solver clingo -A -loutput ' + extend(name, 'sp') + \
            ' > ' + extend(name, 'txt')
    print(cmd)
names = [    'brain', 'card_constr', 'ch5', 'comment', 'formula', 'free_vars', 
            'func_terms', 'graphs', 'pi1', 'pi2', 'pi3', 'ranking', 'sentence_head',
            'switchover', 't3', 'vu_test']
            
########## ########## ########## ########## ########## ########## ########## ##########
########## ########## ########## ########## ########## ########## ########## ##########

if __name__ == '__main__':
    print('cls')
    for name in names:
        name = 'examples/' + name
        # parse(name)
        # solve(name)
        translate(name)
        output(name)